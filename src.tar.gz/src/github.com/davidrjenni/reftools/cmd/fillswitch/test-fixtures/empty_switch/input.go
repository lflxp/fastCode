package p

import _ "sort"

func test() {
	switch {
	}
}
