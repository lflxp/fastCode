package second

type T struct{}

//Foo this doesn't work but should
func (t T) Foo() {}
