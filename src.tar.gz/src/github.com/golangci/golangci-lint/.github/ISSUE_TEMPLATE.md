Thank you for creating the issue!

Please include the following information:
1. Version of golangci-lint: `golangci-lint --version` (or git commit if you don't use binary distribution)
2. Config file: `cat .golangci.yml`
3. Go environment: `go version && go env`
4. Verbose output of running: `golangci-lint run -v`