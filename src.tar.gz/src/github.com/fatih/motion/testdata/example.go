package main

type T struct{}

func (t T) ExampleMethod() string {
	return "example method"
}
